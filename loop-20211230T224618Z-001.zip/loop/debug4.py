n=int(input("enter"))
i=1
sum=0
while i<=n:
    if n%2==0:
        sum=sum+1
    i+=1
print("sum of even no",sum)