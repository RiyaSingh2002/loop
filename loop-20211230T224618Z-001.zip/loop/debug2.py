i=1
while (i<=140):
    if (i%3==0):
        sum=sum+i
        i=i-1
    print(sum)