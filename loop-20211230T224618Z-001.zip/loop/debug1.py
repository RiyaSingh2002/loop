index=1
while (index<10):
    print(index)
    index=index+1