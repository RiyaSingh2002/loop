i=556
while i<=656:
    z=i-556
    if z%7==0:
        print(z)
    i=i+1