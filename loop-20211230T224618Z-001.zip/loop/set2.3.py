i=50
sum=0
while i<=60:
    z=i-49
    num1=int(input("enter a number"))
    sum=sum+num1
    print(sum)
    i=i+1