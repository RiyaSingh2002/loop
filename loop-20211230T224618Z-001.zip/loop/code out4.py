i=0
while(i<5):
    j=0
    while(i<5):
        if(j>3):
            break
        else:
            print ("*")
            j=j+1
        print (" ")
        i=i+1