i=2
num=1
while (i<num):
    if(num%1==0):
        print("num,is not a prime number")
        break
    i=i+1
else:
    print("num,is a primr number")