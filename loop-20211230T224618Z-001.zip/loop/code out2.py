n=6
s=0
i=1
while i<=n:
    s=s+1
    print(s)
    i=i+1
