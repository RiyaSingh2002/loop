i=1
sum=0
n=int(input("enter a number"))
while i<=n:
    n1=int(input("enter a number"))
    sum=sum+n1
    print(sum)
    i=i+1