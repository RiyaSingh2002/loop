i = 0
while i <= 50:
  if i != 0:
    print(i)
  i = i + 5 