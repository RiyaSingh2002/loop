i=156
while i<=166:
    z=i-155
    print(z)
    i=i+1