# i=1
# while i<=100:
#     if i%7==0:
#         print(i)
#     i=i+1
n=int(input("enter a number"))
i=n
while i<=100:
    if i%7==0:
        print(i)
    i=i+1