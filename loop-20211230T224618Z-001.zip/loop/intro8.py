i=1
num=6
while i<=10:
    num1=int(input("enter a number"))
    if num>num1:
        print("aapka number bada hai")
    elif num<num1:
        print("aapka number chhota hai")
    else:
        print("aapne number gues kar liya hai")
        break
    i=i+1