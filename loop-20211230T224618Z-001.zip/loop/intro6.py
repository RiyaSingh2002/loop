# start=0
# start=int(input('enter any number'))
# end=int(input('enter any number'))
# while start<=end:
#     if start%2==0:
#         print(start)
#     start=start+1
i=1
while i<=100:
    if i%2==0:
        print(-i)
    else:
        print(i)
    i=i+1