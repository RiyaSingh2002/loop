i = 49
while i <= 98:
  i = i + 2
  print(i) 