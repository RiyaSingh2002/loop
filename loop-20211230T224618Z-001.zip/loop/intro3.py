i=12
sum=12
while i<=421:
    sum=sum+i
    i=i+1
print(sum)
    