i=1
while i<=100:
    if i%2==0:
        print(-i)
    else:
        print(i)
    i=i+1