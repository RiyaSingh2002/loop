num1=int(input("enter a number"))
num2=int(input("enter a number"))
i=1
sum=0
while i<=num1:
    sum=sum+num2
    i=i+1
print(sum)


