i=1
c=0
n=int(input("emter a number"))
while i<=n:
    if n%i==0:
        c+=1
    i+=1        
if c==2:
    print("it is prime number")
else:
    print("it is not prime number")