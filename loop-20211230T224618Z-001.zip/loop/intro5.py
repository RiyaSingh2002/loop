i=1
avarege=0
sum=0
while i<=11:
    num=int(input("enter a wt"))
    sum=sum+num
    i=i+1
    average=sum/11
if average%5==0:
    print('average')
else:
    print("no value")
    
        

