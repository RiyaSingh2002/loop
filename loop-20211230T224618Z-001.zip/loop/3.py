i=0
sum=0
while i<=100:
    sum=sum+i
    i=i+1
print(sum)