 
i = 891
while i < 931:
  z = i - 890
  if z % 3 == 0:
    print(z)
  i = i + 1 
