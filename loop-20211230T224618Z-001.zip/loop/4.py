# i=1
# sum=1
# while i<=10:
#     num=int(input("entera number"))
#     sum=sum+num
#     print(sum)
#     break
# i=i+1
i=1
sum=0
num=int(input("enter a number"))
while i<=num:
    num1=int(input("enter a number"))
    sum=sum+num1
    i=i+1
print(sum)