c=0
d=1
while c<3:
    c=c+1
    d=d*c
    print("loop ke ander hai",c,d)
else:
    print("loop ke bahar hai",c,d)
    