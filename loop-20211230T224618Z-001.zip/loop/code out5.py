x=0
while (x<7):
    if(x==3 or x==5):
        x=x+1
        continue
    print(x)
    x=x+1