i=30
sum=i%8==0
while i<=420:
    sum=sum+i
    i=i+1
print(sum)
    
    