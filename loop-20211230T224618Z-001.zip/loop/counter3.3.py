 
i = 400
while i >= 350:
  z = i - 300
  if z % 2 != 0:
      print(z)
  i = i - 1