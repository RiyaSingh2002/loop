i=1
num1=7
while i<=5:
    num=int(input("enter a number"))
    if num!=num1:
        print("aapne galat number gues kiya hai")
    else:
        print("wah aapne sahi number gues kiya")
        break
    i=i+1





