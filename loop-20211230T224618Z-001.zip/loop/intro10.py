first=0
second=1
while first<=100:
    print(first)
    c=first
    first=second
    second=c+second

