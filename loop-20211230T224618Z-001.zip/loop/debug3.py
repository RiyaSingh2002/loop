i=0
while(i<=10):
    j=0
    while (j<=5):
        print(j)
        j=j+1
        i=i+1